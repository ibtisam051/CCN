# TCP_SOCKET

Basic TCP Client/Server communication :


Build Steps :
1. gcc -o server server.c
2. gcc -o client client.c




Execute Steps :
1. Run the server using ./server
2. Run clients in other terminals ./client
3. Server default listening port = 9000 on localhost


NOTE:
Its for beginners ,who want to experience the socket
code and analyse the problems during coding. There is always
hope for changes in this code ,so please send the pull request
for changes

