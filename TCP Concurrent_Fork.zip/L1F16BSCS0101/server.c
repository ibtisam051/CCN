// Server side implementation of UDP client-server model
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <string.h>
#include <ctype.h>

#define PORT	 8080
#define MAXLINE 1024

// Driver code
int main() {
	int sockfd;
	char buffer[MAXLINE];
	char *hello = "hello Client";
	struct sockaddr_in servaddr, cliaddr;

	// Creating socket file descriptor
	if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 ) {
		perror("socket creation failed");
		exit(EXIT_FAILURE);
	}

	memset(&servaddr, 0, sizeof(servaddr));
	memset(&cliaddr, 0, sizeof(cliaddr));

	// Filling server information
	servaddr.sin_family = AF_INET; // IPv4
	servaddr.sin_addr.s_addr = INADDR_ANY;
	servaddr.sin_port = htons(PORT);

	// Bind the socket with the server address
	if ( bind(sockfd, (const struct sockaddr *)&servaddr, sizeof(servaddr)) < 0 )
	{
		perror("bind failed");
		exit(EXIT_FAILURE);
	}

	int len = sizeof(cliaddr);

  listen(sockfd,10);

  while(1)
  {
    int newfd = accept(sockfd,(struct sockaddr *)&cliaddr,(socklen_t *)&len);

		int pid = fork();


		if(pid == -1)
		{exit(-1);}
		else if(pid == 0)
		{
			close(sockfd);

			int* portClient = (int*) malloc (sizeof(int) * 2);

			portClient[0] = ntohs(cliaddr.sin_port);
			printf("\nClient with port %d : ",portClient[0] );

			int n = recv(newfd,buffer,MAXLINE,0);
			buffer[n] = '\0';
			send(newfd,(int*)portClient,sizeof(portClient),0);

			write(1,buffer,strlen(buffer));

			send(newfd,hello,strlen(hello),0);

			exit(1);
		}
		else
		{
			close(newfd);
		}
		printf("\n");
  }

	return 0;
}
